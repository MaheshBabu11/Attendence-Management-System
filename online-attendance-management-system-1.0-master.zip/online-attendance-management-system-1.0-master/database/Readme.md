## Database
MySQL is used as database. Database design is made easy to understand.
## Importing Database
- Download the given \*.sql file.
- Create a database attsystem
- Import \*.sql, if everything Okay then database will be imported.
## Tables
- admininfo
- teachers
- students
- attendance
- reports (as view)
