<?php
    include './Database/Controler.php';
    
    if(isset($_REQUEST['lid'])=="green")
    {
          echo '0';
            
    }
    else
    {
       echo '1';
    }
        
?>
