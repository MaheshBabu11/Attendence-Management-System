<?php
    include './Database/Controler.php';
    include 'role.php';
?>

<h2>Contact Details</h2> 
<div class="row">
          <div class="col-md-12">
          <div class="panel panel-default">
          <div class="panel-body">
          <div class="table-responsive">
          
         <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                   <td><center><br><img src="img/u.jpg" height="20%" width="30%" style="border-radius:50%;"></center><br>
                        <b><h3><center>URMI SONI</center></h3></b>
                        <h4><center><b>Email:</b>urmisoni456@gmail.com</center>
                        <h4><center><b>Contact Number:</b>123456789</center>
                   </td>
                   <td> <center><br><img src="img/c.jpg" height="20%" width="28%" style="border-radius:50%;"></center>  
                         <br>
						 <b><h3><center>CHANDNI SONI</center></h3></b>
                                <h4><center><b>Email:</b>soni.chandni.415@gmail.com</center>
                                <h4><center><b>Contact Number:</b>123456789</center>
                   </td>
          </table>
<?php
include 'footer.php';
?>
