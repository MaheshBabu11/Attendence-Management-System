<?php
include './Database/Controler.php';
include 'role.php';
?>
<hr/>
<h2>Attendance Sheet</h2>   
</div>
</div>
                 <!-- /. ROW  -->
                 
 <form method="post" role="form"   enctype="multipart/form-data">
   <div class="body"> 
        <div class="dataTables_wrapper form-inline dt-bootstrap" id="DataTables_Table_0_wrapper">
           <div class="row">
              <div class="col-sm-6">
                  <div class="dataTables_length" id="DataTables_Table_0_length">
                        
                  </div>
              </div>
           </div>
        </div>
        <div class="row">
            <div class="col-sm-12">
            </div>
        </div>
   </div>
</form>
</div>
</div>
</div>
</div>
 <!-- /. PAGE INNER  -->
</div>
         <!-- /. PAGE WRAPPER  -->
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
<?php
    include 'footer_table.php';
?>