<!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    <!-- mine -->
    <!-- Bootstrap Core Js -->
    <script src="assets/js1/bootstrap.js"></script>

    <!-- Select Plugin Js -->
    <script src="assets/js1/bootstrap-select.js"></script>

    <!-- Slimscroll Plugin Js -->
    <script src="assets/js1/jquery.slimscroll.js"></script>

    <!-- Waves Effect Plugin Js -->
    <script src="assets/js1/waves.js"></script>

    <!-- Custom Js -->
    <script src="assets/js1/admin.js"></script>

    <!-- Demo Js -->
    <script src="assets/js1/demo.js"></script>
    <!-- for table -->
    <script src="assets/js1/jquery.dataTables.js"></script>
    <script src="assets/js1/dataTables.buttons.min.js"></script>
    <script src="assets/js1/dataTables.bootstrap.js"></script>
    <script src="assets/js1/buttons.print.min.js"></script>
    <script src="assets/js1/buttons.html5.min.js"></script>
    <script src="assets/js1/buttons.flash.min.js"></script>
    <script src="assets/js1/jquery.slimscroll.js"></script>
    <script src="assets/js1/jquery-datatable.js"></script>
   
</body>
</html>