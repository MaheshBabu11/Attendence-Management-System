# attendance-management-system
Online attendance management

This system starts on Xamp Server 
Steps to Start 
1. Open Xamp
2. Start MySQL and apache server 
3. Inside Xamp folder(generally located in C drive) Create a new Folder named WEBD inside HTDOCS Folder and paste all the files there.
4. Open your Favorite browser and type localhost/WEBD/index.php
5. Your application has started now

Functionalities 
1. Student Have to Register before the Semister.
2. Teacher will be given login details by Admin.
3. Teachers will fill the attendence daily as per classes and it would be reflected on the student dashboard

Database

1.the file with sql extensions are databases required for functioning of above design

front-end

1.based on Material design bootstrap(https://mdbootstrap.com/getting-started/)

- css cdn file https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.3.2/css/mdb.min.css
- js cdn file https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.3.2/js/mdb.min.js

Gear Up and use the project
