# AttendanceMS
Attendance Management System


## Installation

$ docker run --rm -v $(pwd):/app composer install


$ docker-compose up -d

$ docker-compose exec web php artisan migrate

