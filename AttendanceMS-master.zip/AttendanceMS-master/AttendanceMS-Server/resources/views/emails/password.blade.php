Click here to reset your password: {{ url('password/token/'.$token) }}
<br>
If it was not you please inform Us : {{ url('password/delete/'.$token) }}