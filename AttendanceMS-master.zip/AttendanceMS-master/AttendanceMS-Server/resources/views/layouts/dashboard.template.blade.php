@extends('layouts.plane2')


@section('style')
    <style>
    </style>
    @yield('page_style')
@endsection



@section('body')

@endsection




@section('script')
    <script>
    </script>
    @yield('page_script')
@endsection


